public class PremierLeagueSystem {

//Run this method
    public static void main(String[] args) {
        //simply created a referance of class premier leauge manager
    PremierLeagueManager p = new PremierLeagueManager(20);

    }
}
