
//An empty interface for the league manager
public interface myLeagueManager {
}
