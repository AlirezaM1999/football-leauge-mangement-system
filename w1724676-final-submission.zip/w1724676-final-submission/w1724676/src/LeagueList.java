//Displaying all teams in acsending order
//Team with the highest score is placed in the top
//If two teams have the same points, list is descended base on goal difference


import java.util.*;

public abstract class LeagueList implements Comparator<FootballClub> {


    public int comparePoints(FootballClub c1, FootballClub c2){
        if(c1.getNumberOfPoints() > c2.getNumberOfPoints())
            return -1;
        else
            if(c1.getNumberOfPoints() < c2.getNumberOfPoints())
                return 1;
            else{
                int difference1 = c1.getScoredGoalsNum()-c1.getRecivedGoalsNum();
                int difference2 = c2.getScoredGoalsNum()-c2.getRecivedGoalsNum();
                return Integer.compare(difference2, difference1);

            }
    }
}
