












//setting up the abstract class with name location and stats for the clubs
public abstract class Club {
    private String clubName;
    private String clubLocation;
    private String clubStatistics;


    @Override
    public boolean equals(Object e){
        return clubName.equals(((Club)e).clubName);
    }

//return statements for returning the values
    public String getClubName(){
        return clubName;
    }
    public String getClubLocation(){
        return clubLocation;
    }
    public String getClubStatistics(){
        return clubStatistics;
    }
//Creating Constructors with arguments
    public void setClubLocation(String p){
        this.clubLocation = p;
    }
    public void setClubName(String p){
        this.clubName = p;
    }


}
