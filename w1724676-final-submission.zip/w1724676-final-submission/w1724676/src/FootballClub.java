
//Am extention of club with integers
//Contents of this class are called in show stats method in class PremierLeagueManager
public class FootballClub extends Club {

    private int winNum;
    private int drawNum;
    private int defeatNum;
    private int scoredGoalsNum;
    private int numberOfPoints;
    private int recievedGoalsNum;
    private int totalPlayedMatches;
//return statements for the integers
//Returns the value store valued when called
    public int getWinNum(){
        return winNum;
    }
    public int getDrawNum(){
        return drawNum;
    }
    public int getDefeatNum(){
        return defeatNum;
    }
    public int getScoredGoalsNum(){
        return scoredGoalsNum;
    }
    public int getRecivedGoalsNum(){
        return recievedGoalsNum;
    }
    public int getTotalPlayMatches(){
     return totalPlayedMatches;
    }
    public int getNumberOfPoints(){
        return numberOfPoints;
    }

  //setting methods for the integers
  public void setWinNum(int i){
        winNum = i;
  }
  public void setDrawNum(int i){
    drawNum = i;
  }
    public void setDefeatNum(int i){
        defeatNum = i;
    }
    public void setScoredGoalsNum(int i){
        scoredGoalsNum = i;
    }
    public void setRecievedGoalsNum(int i){
        recievedGoalsNum = i;
    }
    public void setTotalPlayedMatches(int i){
        totalPlayedMatches = i;
    }
    public void setNumberOfPoints(int i){
        numberOfPoints = i;
    }











}
