import java.text.ParseException; //importing the needed packages for the this classes
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class PremierLeagueManager implements myLeagueManager {

    private  int totalClubNum;                  //maximum number of clubs allowed in the list (this is changable on the main method), but now it is set to 20
    private  ArrayList<FootballClub> league;   //An array list of all matches are stored here
    private  Scanner scanner;                 //Scanner intialisation for taking users' input
    private  ArrayList<footballMatch> matches;  //An array list of all matches are stored here

    public PremierLeagueManager(int totalClubNum) {
        this.totalClubNum = totalClubNum;
        league = new ArrayList<>();
        matches = new ArrayList<>();
        scanner = new Scanner(System.in);
        Menu();
    }

    private void Menu() {  //Main menu when the program runs, (On a while loop)
        while (true) {
            System.out.println((" Main menu "));
            System.out.println("Press 1 to create a new football club and add it to the league");
            System.out.println("Press 2 to delete a team from the league");
            System.out.println("Press 3 to display the team stats");
            System.out.println("Press 4 to display the table");
            System.out.println("Press 5 to add a played match");

            String line1 = scanner.nextLine();
            int foo = 0;
            try {
                foo = Integer.parseInt(line1);
            } catch (Exception ignored) {  //using case statements for the options
            }
            switch (foo) {
                case 1:
                    add();
                    break;
                case 2:
                    delete();
                    break;
                case 3:
                    showStats();
                    break;
                case 4:
                    displayTable();
                    break;
                case 5:
                    addMatch();
                    break;

                default:  //if any other key is entered the user will get this message the system returns to main menu
                   System.out.println("wrong key, try again");
                break;
            }
        }
    }
//Method for adding teams to the league
    private void add(){
        if(league.size()== totalClubNum){ //if the user tries to add more clubs the the specified number of clubs, they will get this error
            System.out.println("league is full!");
            return; //Takes the user back to the main menu
        }
        FootballClub c1 = new FootballClub(); //a reference variable of football club
        System.out.println("Please insert the name of the club: ");
        String l = scanner.nextLine();
        c1.setClubName(l);

        //Using if statement to sure same club can not be part of the list twice
        if(league.contains(c1)){
            System.out.println("This club is already added to them list!");
            return;
        }
        //Taking the input and store the value in clubLocation
        System.out.println("Please enter the location of the club: ");
        l = scanner.nextLine();
        c1.setClubLocation(l);
        league.add(c1);
        System.out.println("The club was successfully added to the list.");
    }

//Method for deleting teams
    private void delete(){
        System.out.println("Enter the club name: ");
        String l = scanner.next();
        for(FootballClub club: league){
            if(club.getClubName().equals(l)){
                league.remove(club);
                System.out.println(club.getClubName()+ " HAS BEEN REMOVED!!");
                return;
            }
        }//if the name of the club is not in the list
        System.out.println("This club does not exist");
    }



//Method for displaying statistics

    private void showStats(){
        System.out.println("Enter the club name you want the statistics for: ");
        String l = scanner.nextLine();
        for (FootballClub club : league){
            if(club.getClubName().equals(l)){
                System.out.println("Club name: "+ club.getClubName()+" Matches won: "+ club.getWinNum());
                System.out.println("                   Matches lost: "+ club.getDefeatNum());
                System.out.println("                   Club location: " + club.getClubLocation());
                System.out.println("                   Matches drawn: "+ club.getDrawNum());
                System.out.println("                   Goals scored: "+ club.getScoredGoalsNum());
                System.out.println("                   Goals received: "+ club.getRecivedGoalsNum());
                System.out.println("                   Number of points: "+ club.getNumberOfPoints());
                System.out.println("                   Matches played: "+ club.getTotalPlayMatches());
                return;
            }
        }
        System.out.println("This club does not exist! ");
    }



//Method for showing the table

    private void displayTable(){
        league.sort(new LeagueList() {
            public int compare(FootballClub o1, FootballClub o2) {
                return 0;
            }
        }); {
            for(FootballClub club : league){
                System.out.println(" Club name: "+ club.getClubName()+", Club points: "
                + club.getNumberOfPoints()+" GD: " + ((0)));

            }

        }

    }

//method for adding a played match

    public void addMatch(){ // using default java date format for date mm/dd/yyy
        System.out.println("Enter the of the match with the following format ==> month/day/year: ");
        String l = scanner.nextLine();
        Date date = null;  //Initialise date to null
        try{
            date = new SimpleDateFormat("MM-dd-yyy").parse(l);
        }catch (ParseException ignored){
        }
        System.out.println("Please enter name of home team: ");
        l = scanner.nextLine();
        FootballClub homeTeam = null;
          for(FootballClub club : league){ //checking if the entered club exsists in the league
              if(club.getClubName().equals(l))
                  homeTeam = club;
          }
          if (homeTeam == null){//Message shown if the club is not in the array list
              System.out.println("This club does not exist in the table!");
              return; //takes the user back to the main menu
          }
        System.out.println("Please enter the name of the away team: ");
          l = scanner.nextLine();
          FootballClub awayTeam = null;
        for(FootballClub club : league){
            if(club.getClubName().equals(l))
                awayTeam = club;
        }
        if (awayTeam == null){
            System.out.println("This club does not exist in the table!");
            return;
        }
        System.out.println("Please enter the scored goals for the home team: ");//taking the number goals, this is important for determining goal difference
        l = scanner.nextLine();
        int hGoals = -1;
            try{
                hGoals = Integer.parseInt(l);
            }catch (Exception ignored){
            }
            if(hGoals == -1){//Making sure the user can not input negative value for goals
                System.out.println(" You can not have a negative score! Try again! ");
                return;
            }
//same method for the awayt team
        System.out.println("Please enter scored goals for the away team: ");
        l = scanner.nextLine();
        int aGoals = -1;
        try{
            aGoals = Integer.parseInt(l);
        }catch (Exception ignored){
        }
        if(aGoals == -1){
            System.out.println("You can not have a negative score! Try again!");
            return;
        }

        footballMatch match = new footballMatch();
        match.setMatchDate(date);
        match.setTeam1(homeTeam);
        match.setTeam2(awayTeam);
        match.setScore1(aGoals);
        match.setScore2(hGoals);
        matches.add(match);
        homeTeam.setScoredGoalsNum(homeTeam.getScoredGoalsNum()+hGoals);
        awayTeam.setScoredGoalsNum(awayTeam.getScoredGoalsNum()+aGoals);
        homeTeam.setRecievedGoalsNum(homeTeam.getRecivedGoalsNum()+aGoals);
        awayTeam.setRecievedGoalsNum(awayTeam.getRecivedGoalsNum()+hGoals);

        //updating the match count for every played match
        homeTeam.setTotalPlayedMatches(homeTeam.getTotalPlayMatches()+1);
        awayTeam.setTotalPlayedMatches(awayTeam.getTotalPlayMatches()+1);


        if (hGoals > aGoals){//setting the number points and win and defeat count if the home team scores
            homeTeam.setNumberOfPoints(homeTeam.getNumberOfPoints()+3);
            homeTeam.setWinNum(homeTeam.getWinNum()+1);
            awayTeam.setDefeatNum(awayTeam.getDefeatNum()+1);
        }

        else if  (hGoals < aGoals){//setting the number points and win and defeat count if the home away team scores
            awayTeam.setNumberOfPoints(awayTeam.getNumberOfPoints()+3);
            awayTeam.setWinNum(awayTeam.getWinNum()+1);
            homeTeam.setDefeatNum(homeTeam.getDefeatNum()+1);
        }
        else {//if the match is a draw ,Both teams will earn a point and matches played count is updated
            homeTeam.setNumberOfPoints(homeTeam.getNumberOfPoints()+1);
            awayTeam.setNumberOfPoints(awayTeam.getNumberOfPoints()+1);
            homeTeam.setDrawNum(homeTeam.getDrawNum()+1);
            awayTeam.setDrawNum(awayTeam.getDrawNum()+1);
        }




    }




















}
