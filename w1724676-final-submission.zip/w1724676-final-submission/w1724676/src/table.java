
//Run this seperaly
//Run table.main
//An example of table interface



import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Comparator;

public class table{

    public static void main(String[] args) {

        // create JFrame and JTable
        JFrame frame = new JFrame();
        JTable table = new JTable();
        table.setAutoCreateRowSorter(true);

        TableRowSorter<TableModel> sorter
                = new TableRowSorter<TableModel>(table.getModel());
        table.setRowSorter(sorter);


        Comparator<String> comparator = new Comparator<String>() {
            public int compare(String s1, String s2) {
                String[] strings1 = s1.split("\\s");
                String[] strings2 = s2.split("\\s");
                return strings1[strings1.length - 1]
                        .compareTo(strings2[strings2.length - 1]);
            }
        };




        Container c = frame.getContentPane();
        c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
        c.add(table);

        // create a table model and set a Column Identifiers to this model
        Object[] columns = {"Team name", "Wins", "Losses", "Goals Difference","Points","Matches played"};

        DefaultTableModel model = new DefaultTableModel();

        model.setColumnIdentifiers(columns);

        // set the model to the table
        table.setModel(model);

        // Change A JTable Background Color, Font Size, Font Color, Row Height
        table.setBackground(Color.LIGHT_GRAY);
        table.setForeground(Color.black);
        Font font = new Font("", 1, 22);
        table.setFont(font);
        table.setRowHeight(30);
        //  table.setVisible(true);

        // create JTextFields
        JTextField txtTeamName = new JTextField();
        JTextField txtWins = new JTextField();
        JTextField txtLosses = new JTextField();
        JTextField txtGD = new JTextField();
        JTextField txtPoints = new JTextField();
        JTextField txtMatches = new JTextField();

        JLabel lblTeamName = new JLabel("Team name");
        JLabel lblWins = new JLabel("Wins");
        JLabel lblLosses = new JLabel("Losses");
        JLabel lblGD = new JLabel("Goal difference");
        JLabel lblPoints = new JLabel("Points");
        JLabel lblMatches = new JLabel("Matches");

        // create JButtons
        JButton btnAdd = new JButton("Add");
        JButton btnDelete = new JButton("Delete");
        JButton btnUpdate = new JButton("Update");
        JButton btnSortPoints = new JButton("Sort by points");
        JButton btnSortGoals = new JButton("Sort by goals");
        JButton btnRandomMatch = new JButton("Add a random data");


        txtTeamName.setBounds(1200, 230, 100, 25);
        txtWins.setBounds(1200, 260, 100, 25);
        txtLosses.setBounds(1200, 290, 100, 25);
        txtGD.setBounds(1200, 320, 100, 25);
        txtMatches.setBounds(1200,350,100,25);
        txtPoints.setBounds(1200,380,100,25);

        lblTeamName.setBounds(1100,230,100,25);
        lblWins.setBounds(1100,260,100,25);
        lblLosses.setBounds(1100,290,100,25);
        lblGD.setBounds(1100,320,100,25);
        lblMatches.setBounds(1100,350,100,25);
        lblPoints.setBounds(1100,380,100,25);



        btnAdd.setBounds(1150, 20, 200, 50);
        btnUpdate.setBounds(1150, 80, 200, 50);
        btnDelete.setBounds(1150, 140, 200, 50);
        btnSortGoals.setBounds(920,20,200,50);
        btnSortPoints.setBounds(920,80,200,50);
        btnRandomMatch.setBounds(920,140,200,50);

        // create JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(0, 0, 880, 400);

        frame.setLayout(null);

        frame.add(pane);

        // add JTextFields to the jframe
        frame.add(txtTeamName);
        frame.add(txtWins);
        frame.add(txtLosses);
        frame.add(txtGD);
        frame.add(txtMatches);
        frame.add(txtPoints);


        //Adding the labels to the frame
        frame.add(lblTeamName);
        frame.add(lblWins);
        frame.add(lblLosses);
        frame.add(lblGD);
        frame.add(lblMatches);
        frame.add(lblPoints);

        // add JButtons to the jframe
        frame.add(btnAdd);
        frame.add(btnDelete);
        frame.add(btnUpdate);
        frame.add(btnSortGoals);
        frame.add(btnSortPoints);
        frame.add(btnRandomMatch);

        // create an array of objects to set the row data
        Object[] row = new Object[6];

        // button add row
        btnAdd.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {

                row[0] = txtTeamName.getText();
                row[1] = txtWins.getText();
                row[2] = txtLosses.getText();
                row[3] = txtGD.getText();
                row[4] = txtMatches.getText();
                row[5] = txtPoints.getText();

                // add row to the model
                model.addRow(row);
            }
        });

        // Event listener for button remove row
        btnDelete.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {

                // i = the index of the selected row
                int i = table.getSelectedRow();
                if(i >= 0){
                    // remove a row from jtable
                    model.removeRow(i);
                }
                else{
                    System.out.println("Delete Error");
                }
            }
        });

        // get selected row data From table to textfields
        table.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e){

                // i = the index of the selected row
                int i = table.getSelectedRow();

                txtTeamName.setText(model.getValueAt(i, 0).toString());
                txtWins.setText(model.getValueAt(i, 1).toString());
                txtLosses.setText(model.getValueAt(i, 2).toString());
                txtGD.setText(model.getValueAt(i, 3).toString());
                txtMatches.setText(model.getValueAt(i,4).toString());
                txtPoints.setText(model.getValueAt(i,5).toString());
            }
        });

        // button update row
        btnUpdate.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed (ActionEvent e) {

                // i = the index of the selected row
                int i = table.getSelectedRow();

                if(i >= 0)
                {
                    model.setValueAt(txtTeamName.getText(), i, 0);
                    model.setValueAt(txtWins.getText(), i, 1);
                    model.setValueAt(txtLosses.getText(), i, 2);
                    model.setValueAt(txtGD.getText(), i, 3);
                    model.setValueAt(txtMatches.getText(),i,4);
                    model.setValueAt(txtPoints.getText(),i,5);
                }
                else{
                    System.out.println("Update Error");
                }
            }
        });

        btnSortPoints.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

//                List <RowSorter.SortKey> sortKeys
//                        = new ArrayList<RowSorter.SortKey>();
//                sortKeys.add(new RowSorter.SortKey(1, SortOrder.ASCENDING));
//                sortKeys.add(new RowSorter.SortKey(0, SortOrder.ASCENDING));
//                sorter.setSortKeys(sortKeys);


            }
        });


        frame.setSize(1400, 500);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }

}
